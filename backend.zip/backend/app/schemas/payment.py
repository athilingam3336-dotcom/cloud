"""
=========================================
CloudCrackers
Payment Schemas
=========================================
"""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel


class PaymentRequest(BaseModel):
    order_id: UUID


class PaymentVerify(BaseModel):
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str


class PaymentResponse(BaseModel):
    id: UUID
    order_id: UUID
    razorpay_order_id: str
    razorpay_payment_id: str | None = None
    amount: float
    payment_method: str | None = None
    payment_status: str
    paid_at: datetime | None = None

    class Config:
        from_attributes = True