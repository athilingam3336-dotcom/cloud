"""
=========================================
CloudCrackers
Product Schemas
=========================================
"""

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, Field


class ProductBase(BaseModel):
    category_id: UUID
    product_name: str
    description: str | None = None
    price: float = Field(gt=0)
    stock_quantity: int = Field(ge=0)
    product_image: str | None = None
    status: Literal["ACTIVE", "INACTIVE"] = "ACTIVE"


class ProductCreate(ProductBase):
    pass


class ProductUpdate(BaseModel):
    product_name: str | None = None
    description: str | None = None
    price: float | None = Field(default=None, gt=0)
    stock_quantity: int | None = Field(default=None, ge=0)
    product_image: str | None = None
    status: Literal["ACTIVE", "INACTIVE"] | None = None


class ProductResponse(ProductBase):
    id: UUID
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True