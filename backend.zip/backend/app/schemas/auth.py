"""
=========================================
CloudCrackers
Authentication Schemas
=========================================
"""

from pydantic import BaseModel, EmailStr, Field


# ==========================================
# Register Request
# ==========================================

class RegisterRequest(BaseModel):

    first_name: str = Field(..., min_length=2, max_length=100)

    last_name: str = Field(..., min_length=2, max_length=100)

    email: EmailStr

    phone: str | None = None

    password: str = Field(..., min_length=8)


# ==========================================
# Login Request
# ==========================================

class LoginRequest(BaseModel):

    email: EmailStr

    password: str


# ==========================================
# JWT Token Response
# ==========================================

class TokenResponse(BaseModel):

    access_token: str

    token_type: str = "bearer"


# ==========================================
# Token Payload
# ==========================================

class TokenData(BaseModel):

    email: str | None = None


# ==========================================
# Message Response
# ==========================================

class MessageResponse(BaseModel):

    message: str