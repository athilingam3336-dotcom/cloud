"""
=========================================
CloudCrackers
database.py
Database Connection
=========================================
"""

from sqlalchemy import create_engine
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql.sqltypes import UUID, Uuid

from app.core.config import settings


# ==========================================
# MySQL UUID Compatibility
# ==========================================

@compiles(UUID, "mysql")
@compiles(Uuid, "mysql")
def compile_uuid_for_mysql(type_, compiler, **kwargs):
    return "VARCHAR(36)"


# ==========================================
# Database Engine
# ==========================================

print(f"settings.DATABASE_URL = {settings.DATABASE_URL}")

engine = create_engine(
    settings.DATABASE_URL,
    echo=settings.DEBUG,
    pool_pre_ping=True,
    pool_recycle=3600,
    future=True
)

print(
    "engine.url = "
    f"{engine.url.render_as_string(hide_password=False)}"
)


# ==========================================
# Database Session
# ==========================================

SessionLocal = sessionmaker(
    bind=engine,
    autocommit=False,
    autoflush=False,
    expire_on_commit=False
)


# ==========================================
# Base Class
# ==========================================

Base = declarative_base()


# ==========================================
# Dependency
# ==========================================

def get_db():

    db = SessionLocal()

    try:
        yield db

    finally:
        db.close()
