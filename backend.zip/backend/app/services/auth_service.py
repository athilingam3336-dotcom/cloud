"""
=========================================
Authentication Service
=========================================
"""

from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.models.user import User

from app.schemas.auth import RegisterRequest

from app.utils.password import (
    hash_password,
    verify_password
)


class AuthService:

    @staticmethod
    def register(
        db: Session,
        data: RegisterRequest
    ):

        user = db.query(User).filter(
            User.email == data.email
        ).first()

        if user:
            return None

        new_user = User(
            first_name=data.first_name,
            last_name=data.last_name,
            email=data.email,
            phone=data.phone,
            password_hash=hash_password(
                data.password
            )
        )

        db.add(new_user)

        try:
            db.commit()
        except SQLAlchemyError:
            db.rollback()
            raise

        db.refresh(new_user)

        return new_user

    @staticmethod
    def authenticate(
        db: Session,
        email: str,
        password: str
    ):

        user = db.query(User).filter(
            User.email == email
        ).first()

        if not user:
            return None

        if not verify_password(
            password,
            user.password_hash
        ):
            return None

        return user
