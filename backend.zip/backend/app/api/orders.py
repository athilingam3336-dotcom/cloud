"""
=========================================
CloudCrackers
Order APIs
=========================================
"""

from fastapi import APIRouter
from fastapi import Depends
from fastapi import HTTPException
from fastapi import status

from sqlalchemy.orm import Session

from app.database.database import get_db

from app.middleware.auth import (
    get_current_user,
    get_admin_user
)

from app.models.user import User

from app.schemas.order import (
    OrderCreate,
    OrderUpdate,
    OrderResponse
)

from app.services.order_service import (
    OrderService
)

router = APIRouter()


# ==========================================
# Create Order (Checkout)
# ==========================================

@router.post(
    "/",
    response_model=OrderResponse,
    status_code=status.HTTP_201_CREATED
)
def create_order(
    data: OrderCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):

    try:
        order = OrderService.create_order(
            db,
            current_user.id,
            data.shipping_address
        )
    except ValueError as e:
        raise HTTPException(
            status_code=400,
            detail=str(e)
        )

    if not order:

        raise HTTPException(
            status_code=400,
            detail="Cart is Empty"
        )

    return order


# ==========================================
# Get My Orders
# ==========================================

@router.get(
    "/",
    response_model=list[OrderResponse]
)
def get_orders(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):

    return OrderService.get_orders(
        db,
        current_user.id
    )


# ==========================================
# Get Order By ID
# ==========================================

@router.get(
    "/{order_id}",
    response_model=OrderResponse
)
def get_order(
    order_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):

    order = OrderService.get_order_by_id(
        db,
        order_id,
        current_user.id
    )

    if not order:

        raise HTTPException(
            status_code=404,
            detail="Order Not Found"
        )

    return order


# ==========================================
# Cancel Order
# ==========================================

@router.put(
    "/cancel/{order_id}",
    response_model=OrderResponse
)
def cancel_order(
    order_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):

    order = OrderService.cancel_order(
        db,
        order_id,
        current_user.id
    )

    if not order:

        raise HTTPException(
            status_code=404,
            detail="Order Not Found"
        )

    return order


# ==========================================
# Admin Update Order Status
# ==========================================

@router.put(
    "/status/{order_id}",
    response_model=OrderResponse
)
def update_order_status(
    order_id: str,
    data: OrderUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_admin_user)
):

    order = OrderService.update_order_status(
        db,
        order_id,
        data.order_status
    )

    if not order:

        raise HTTPException(
            status_code=404,
            detail="Order Not Found"
        )

    return order
