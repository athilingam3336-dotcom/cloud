from datetime import datetime, timedelta
from jose import jwt

from app.core.config import settings


def create_access_token(data: dict):
    payload = {}

    # எல்லா values-யும் JSON serializable ஆக convert செய்
    for key, value in data.items():
        payload[key] = str(value)

    expire = datetime.utcnow() + timedelta(
        minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
    )

    payload["exp"] = expire

    return jwt.encode(
        payload,
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM,
    )


def decode_access_token(token: str):
    return jwt.decode(
        token,
        settings.SECRET_KEY,
        algorithms=[settings.ALGORITHM],
    )