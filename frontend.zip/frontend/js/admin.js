/*
==========================================
CloudCrackers
admin.js
Admin Dashboard Module
==========================================
*/

document.addEventListener("DOMContentLoaded", () => {

    loadDashboard();

    initializeProductForm();

    initializeCategoryForm();

});


/*
==========================================
Dashboard
==========================================
*/

async function loadDashboard() {

    try {

        /*
        const dashboard =
        await apiGet("/admin/dashboard");
        */

        const dashboard = {

            revenue: "₹8,42,600",

            orders: 1284,

            users: 6530,

            products: 238

        };

        setValue("totalRevenue", dashboard.revenue);

        setValue("totalOrders", dashboard.orders);

        setValue("totalUsers", dashboard.users);

        setValue("totalProducts", dashboard.products);

    }

    catch (error) {

        console.error(error);

    }

}


/*
==========================================
Products
==========================================
*/

function initializeProductForm() {

    const form =
        document.getElementById("productForm");

    if (!form) return;

    form.addEventListener("submit", async (event) => {

        event.preventDefault();

        const product = {

            product_name:
                getValue("productName"),

            price:
                getValue("price"),

            stock:
                getValue("stock"),

            category:
                getValue("category")

        };

        console.log(product);

        /*
        await apiPost(
            "/admin/products",
            product
        );
        */

        alert("Product Saved Successfully");

    });

}


/*
==========================================
Categories
==========================================
*/

function initializeCategoryForm() {

    const form =
        document.getElementById("categoryForm");

    if (!form) return;

    form.addEventListener("submit", async (event) => {

        event.preventDefault();

        const category = {

            category_name:
                getValue("categoryName")

        };

        console.log(category);

        /*
        await apiPost(
            "/admin/categories",
            category
        );
        */

        alert("Category Saved");

    });

}


/*
==========================================
Delete Product
==========================================
*/

async function deleteProduct(productId) {

    if (!confirm("Delete Product?"))
        return;

    console.log(productId);

    /*
    await apiDelete(
        `/admin/products/${productId}`
    );

    */

}


/*
==========================================
Delete Category
==========================================
*/

async function deleteCategory(categoryId) {

    if (!confirm("Delete Category?"))
        return;

    console.log(categoryId);

    /*
    await apiDelete(
        `/admin/categories/${categoryId}`
    );

    */

}


/*
==========================================
Orders
==========================================
*/

async function updateOrderStatus(orderId, status) {

    console.log(orderId, status);

    /*
    await apiPut(

        `/admin/orders/${orderId}`,

        {

            status

        }

    );

    */

}


/*
==========================================
Users
==========================================
*/

async function blockUser(userId) {

    console.log(userId);

    /*
    await apiPut(

        `/admin/users/${userId}`,

        {

            status: "BLOCKED"

        }

    );

    */

}


/*
==========================================
Helper Functions
==========================================
*/

function getValue(id) {

    const element =
        document.getElementById(id);

    if (!element) return "";

    return element.value.trim();

}

function setValue(id, value) {

    const element =
        document.getElementById(id);

    if (!element) return;

    element.textContent = value;

}