const api = {

    async request(endpoint, method = "GET", data = null, auth = false) {

        const headers = {
            "Content-Type": "application/json"
        };

        if (auth) {

            const token = localStorage.getItem(TOKEN_KEY);

            if (token) {
                headers["Authorization"] = `Bearer ${token}`;
            }

        }

        const options = {
            method: method,
            headers: headers
        };

        if (data) {
            options.body = JSON.stringify(data);
        }

        const response = await fetch(API_BASE_URL + endpoint, options);

        let result = {};

        try {
            result = await response.json();
        } catch {
            result = {};
        }

        if (!response.ok) {

            throw new Error(
                result.detail || "Request Failed"
            );

        }

        return result;

    },

    get(endpoint, auth = false) {

        return this.request(
            endpoint,
            "GET",
            null,
            auth
        );

    },

    post(endpoint, data, auth = false) {

        return this.request(
            endpoint,
            "POST",
            data,
            auth
        );

    },

    put(endpoint, data, auth = false) {

        return this.request(
            endpoint,
            "PUT",
            data,
            auth
        );

    },

    delete(endpoint, auth = false) {

        return this.request(
            endpoint,
            "DELETE",
            null,
            auth
        );

    }

};