/*
==========================================
CloudCrackers
profile.js
Profile Module
==========================================
*/

document.addEventListener("DOMContentLoaded", () => {

    loadProfile();

    initializeProfileForm();

});


/*
==========================================
Load Profile
==========================================
*/

async function loadProfile() {

    try {

        /*
        const user =
        await apiGet("/profile");
        */

        // Temporary Dummy Data

        const user = {

            first_name: "Arun",

            last_name: "Kumar",

            email: "arun@gmail.com",

            phone: "9876543210",

            address: "Virudhunagar, Tamil Nadu"

        };

        document.getElementById("firstName").value =
            user.first_name;

        document.getElementById("lastName").value =
            user.last_name;

        document.getElementById("email").value =
            user.email;

        document.getElementById("phone").value =
            user.phone;

        document.getElementById("address").value =
            user.address;

    }

    catch (error) {

        console.error(error);

    }

}


/*
==========================================
Update Profile
==========================================
*/

function initializeProfileForm() {

    const form =
        document.getElementById("profileForm");

    if (!form) return;

    form.addEventListener("submit", async (event) => {

        event.preventDefault();

        const profile = {

            first_name:
                document.getElementById("firstName").value.trim(),

            last_name:
                document.getElementById("lastName").value.trim(),

            email:
                document.getElementById("email").value.trim(),

            phone:
                document.getElementById("phone").value.trim(),

            address:
                document.getElementById("address").value.trim()

        };

        console.log(profile);

        /*
        await apiPut(

            "/profile",

            profile

        );

        */

        alert("Profile Updated Successfully");

    });

}


/*
==========================================
Change Password
==========================================
*/

async function changePassword() {

    const currentPassword =
        document.getElementById("currentPassword").value;

    const newPassword =
        document.getElementById("newPassword").value;

    const confirmPassword =
        document.getElementById("confirmPassword").value;

    if (newPassword !== confirmPassword) {

        alert("Passwords do not match.");

        return;

    }

    console.log({

        currentPassword,

        newPassword

    });

    /*
    await apiPut(

        "/change-password",

        {

            current_password: currentPassword,

            new_password: newPassword

        }

    );
    */

    alert("Password Changed Successfully");

}


/*
==========================================
Delete Account
==========================================
*/

async function deleteAccount() {

    const confirmation =
        confirm(
            "Are you sure you want to delete your account?"
        );

    if (!confirmation) return;

    /*
    await apiDelete("/profile");
    */

    removeToken();

    window.location.href =
        "login.html";

}