/*
==========================================
CloudCrackers
cart.js
Shopping Cart Module
==========================================
*/

document.addEventListener("DOMContentLoaded", () => {

    loadCart();

});


/*
==========================================
Load Cart
==========================================
*/

async function loadCart() {

    const cartContainer =
        document.getElementById("cartContainer");

    if (!cartContainer) return;

    try {

        /*
        const cart =
        await apiGet("/cart");
        */

        // Temporary Dummy Data

        const cart = [

            {

                id: 1,

                name: "Premium Rocket",

                price: 299,

                quantity: 2,

                image: "../images/products/rocket.jpg"

            },

            {

                id: 2,

                name: "Flower Pot",

                price: 499,

                quantity: 1,

                image: "../images/products/flowerpot.jpg"

            }

        ];

        displayCart(cart);

    }

    catch (error) {

        console.error(error);

    }

}


/*
==========================================
Display Cart
==========================================
*/

function displayCart(cartItems) {

    const container =
        document.getElementById("cartContainer");

    if (!container) return;

    container.innerHTML = "";

    let grandTotal = 0;

    cartItems.forEach(item => {

        const subtotal =
            item.price * item.quantity;

        grandTotal += subtotal;

        container.innerHTML += `

        <div class="cart-item">

            <img
                src="${item.image}"
                alt="${item.name}"
            >

            <div>

                <h3>${item.name}</h3>

                <p>₹${item.price}</p>

            </div>

            <div>

                <button
                    onclick="decreaseQuantity(${item.id})"
                >

                    -

                </button>

                <span>

                    ${item.quantity}

                </span>

                <button
                    onclick="increaseQuantity(${item.id})"
                >

                    +

                </button>

            </div>

            <h4>

                ₹${subtotal}

            </h4>

            <button
                onclick="removeCartItem(${item.id})"
            >

                Remove

            </button>

        </div>

        `;

    });

    const total =
        document.getElementById("grandTotal");

    if (total) {

        total.textContent =
            `₹${grandTotal}`;

    }

}


/*
==========================================
Increase Quantity
==========================================
*/

async function increaseQuantity(productId) {

    console.log(productId);

    /*
    await apiPut(

        `/cart/${productId}`,

        {

            quantity: +1

        }

    );

    loadCart();
    */

}


/*
==========================================
Decrease Quantity
==========================================
*/

async function decreaseQuantity(productId) {

    console.log(productId);

    /*
    await apiPut(

        `/cart/${productId}`,

        {

            quantity: -1

        }

    );

    loadCart();

    */

}


/*
==========================================
Remove Cart Item
==========================================
*/

async function removeCartItem(productId) {

    const confirmDelete =
        confirm(
            "Remove this product from cart?"
        );

    if (!confirmDelete) return;

    console.log(productId);

    /*
    await apiDelete(
        `/cart/${productId}`
    );

    loadCart();
    */

}


/*
==========================================
Apply Coupon
==========================================
*/

async function applyCoupon() {

    const coupon =
        document.getElementById("couponCode");

    if (!coupon) return;

    if (coupon.value.trim() === "") {

        alert("Enter Coupon Code");

        return;

    }

    console.log(coupon.value);

    /*
    await apiPost(

        "/coupon",

        {

            code: coupon.value

        }

    );

    */

}


/*
==========================================
Checkout
==========================================
*/

function proceedCheckout() {

    window.location.href =
        "checkout.html";

}