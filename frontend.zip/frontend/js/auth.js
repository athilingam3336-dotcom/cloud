function saveToken(token) {

    localStorage.setItem(
        TOKEN_KEY,
        token
    );

}

function getToken() {

    return localStorage.getItem(
        TOKEN_KEY
    );

}

function logout() {

    localStorage.removeItem(
        TOKEN_KEY
    );

    window.location.href =
        "login.html";

}

async function login(email, password) {

   const result = await api.post(
    "/api/auth/login",
        {
            email: email,
            password: password
        }
    );

    saveToken(
        result.access_token
    );

    window.location.href =
        "products.html";

}

async function register(data) {

    await api.post(
       "/api/auth/register",
        data
    );

    alert(
        "Registration Successful"
    );

    window.location.href =
        "login.html";

}

const loginForm =
    document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener(
        "submit",
        async function (e) {

            e.preventDefault();

            const email =
                document.getElementById("email").value;

            const password =
                document.getElementById("password").value;

            try {

                await login(
                    email,
                    password
                );

            }

            catch (err) {

                const errorBox =
                    document.getElementById("loginError");

                const errorMessage =
                    document.getElementById("errorMessage");

                if (errorBox && errorMessage) {

                    errorBox.style.display = "block";

                    errorMessage.innerText =
                        err.message;

                }

            }

        }

    );

}

const registerForm = document.getElementById("registerForm");

if (registerForm) {

    registerForm.addEventListener(
        "submit",
        async function (e) {

            e.preventDefault();

            const data = {

                first_name:
                    document.getElementById("first_name").value,

                last_name:
                    document.getElementById("last_name").value,

                email:
                    document.getElementById("email").value,

                phone:
                    document.getElementById("phone").value,

                password:
                    document.getElementById("password").value

            };

            try {

                await register(data);

            }

            catch (err) {

                alert(err.message);

            }

        }

    );

}