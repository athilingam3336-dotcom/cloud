/*
==========================================
CloudCrackers
checkout.js
Checkout Module
==========================================
*/

document.addEventListener("DOMContentLoaded", () => {

    loadOrderSummary();

    initializeCheckoutForm();

});


/*
==========================================
Load Order Summary
==========================================
*/

async function loadOrderSummary() {

    try {

        /*
        const summary =
        await apiGet("/checkout");
        */

        // Temporary Dummy Data

        const summary = {

            subtotal: 1999,

            shipping: 0,

            tax: 360,

            total: 2359

        };

        document.getElementById("subtotal").textContent =
            `₹${summary.subtotal}`;

        document.getElementById("shipping").textContent =
            `₹${summary.shipping}`;

        document.getElementById("tax").textContent =
            `₹${summary.tax}`;

        document.getElementById("grandTotal").textContent =
            `₹${summary.total}`;

    }

    catch (error) {

        console.error(error);

    }

}


/*
==========================================
Checkout Form
==========================================
*/

function initializeCheckoutForm() {

    const form =
        document.getElementById("checkoutForm");

    if (!form) return;

    form.addEventListener("submit", async (event) => {

        event.preventDefault();

        placeOrder();

    });

}


/*
==========================================
Place Order
==========================================
*/

async function placeOrder() {

    const order = {

        full_name:
            document.getElementById("fullName").value.trim(),

        phone:
            document.getElementById("phone").value.trim(),

        email:
            document.getElementById("email").value.trim(),

        address:
            document.getElementById("address").value.trim(),

        city:
            document.getElementById("city").value.trim(),

        state:
            document.getElementById("state").value.trim(),

        pincode:
            document.getElementById("pincode").value.trim(),

        payment_method:
            document.querySelector(
                "input[name='payment']:checked"
            ).value

    };

    if (
        order.full_name === "" ||
        order.phone === "" ||
        order.address === ""
    ) {

        alert("Please fill all required fields.");

        return;

    }

    console.log(order);

    /*
    const response =
    await apiPost(
        "/orders",
        order
    );

    window.location.href =
    `orders.html?id=${response.order_id}`;
    */

    alert("Order Placed Successfully!");

}


/*
==========================================
Razorpay Payment
==========================================
*/

async function payWithRazorpay() {

    console.log("Razorpay Payment");

    /*
    const payment =
    await apiPost(
        "/payment/create-order",
        {}
    );

    const options = {

        key: "YOUR_KEY",

        amount: payment.amount,

        currency: payment.currency,

        order_id: payment.order_id

    };

    const razorpay =
        new Razorpay(options);

    razorpay.open();

    */

}


/*
==========================================
Cash On Delivery
==========================================
*/

function cashOnDelivery() {

    alert("Cash On Delivery Selected");

}