/*
==========================================
CloudCrackers
products.js
Products Module
==========================================
*/

document.addEventListener("DOMContentLoaded", () => {

    loadProducts();

    initializeSearch();

    initializeCategoryFilter();

    initializeSort();

});


/*
==========================================
Load Products
==========================================
*/

async function loadProducts() {

    const productContainer =
        document.getElementById("productsContainer");

    if (!productContainer) return;

    try {

        /*
        const products =
        await apiGet("/products");
        */

        // Temporary Dummy Data

        const products = [

            {

                id: 1,

                name: "Premium Rocket",

                price: 299,

                image: "../images/products/rocket.jpg"

            },

            {

                id: 2,

                name: "Flower Pots",

                price: 499,

                image: "../images/products/flowerpot.jpg"

            },

            {

                id: 3,

                name: "Sparklers",

                price: 199,

                image: "../images/products/sparkler.jpg"

            }

        ];

        displayProducts(products);

    }

    catch (error) {

        console.error(error);

    }

}


/*
==========================================
Display Products
==========================================
*/

function displayProducts(products) {

    const container =
        document.getElementById("productsContainer");

    if (!container) return;

    container.innerHTML = "";

    products.forEach(product => {

        container.innerHTML += `

        <div class="product-card">

            <img
                src="${product.image}"
                alt="${product.name}"
            >

            <h3>${product.name}</h3>

            <p>₹${product.price}</p>

            <button
                class="btn btn-primary add-cart-btn"
                data-id="${product.id}"
            >
                Add To Cart
            </button>

        </div>

        `;

    });

    initializeAddToCart();

}


/*
==========================================
Search Products
==========================================
*/

function initializeSearch() {

    const searchInput =
        document.getElementById("searchInput");

    if (!searchInput) return;

    searchInput.addEventListener("keyup", () => {

        console.log(searchInput.value);

        /*
        Later

        apiGet(
        `/products?search=${searchInput.value}`
        )

        */

    });

}


/*
==========================================
Category Filter
==========================================
*/

function initializeCategoryFilter() {

    const category =
        document.getElementById("categoryFilter");

    if (!category) return;

    category.addEventListener("change", () => {

        console.log(category.value);

        /*
        apiGet(
        `/products?category=${category.value}`
        );

        */

    });

}


/*
==========================================
Sort Products
==========================================
*/

function initializeSort() {

    const sort =
        document.getElementById("sortProducts");

    if (!sort) return;

    sort.addEventListener("change", () => {

        console.log(sort.value);

        /*
        price_low

        price_high

        newest

        */

    });

}


/*
==========================================
Add To Cart
==========================================
*/

function initializeAddToCart() {

    const buttons =
        document.querySelectorAll(".add-cart-btn");

    buttons.forEach(button => {

        button.addEventListener("click", () => {

            const productId =
                button.dataset.id;

            console.log(productId);

            /*
            await apiPost(
                "/cart",
                {

                    product_id: productId,

                    quantity: 1

                }

            );
            */

            alert("Product Added To Cart");

        });

    });

}


/*
==========================================
Wishlist
==========================================
*/

async function addToWishlist(productId) {

    console.log(productId);

    /*
    await apiPost(

        "/wishlist",

        {

            product_id: productId

        }

    );
    */

}


/*
==========================================
View Product Details
==========================================
*/

function viewProduct(productId) {

    window.location.href =
        `product-details.html?id=${productId}`;

}